﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegistrationForm.Models
{
    public class ErrorViewModel
    {
        public bool ShowRequestId { get; set; }
        public int RequestId { get; set; }
    }
}
